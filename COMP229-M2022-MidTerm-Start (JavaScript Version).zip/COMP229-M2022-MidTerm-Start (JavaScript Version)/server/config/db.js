module.exports = {
  //local MongoDB deployment ->
  "LocalURI": "mongodb://127.0.0.1/books229",
  "RemoteURI": "your remote host information goes here",
  "HostName": "LocalHost",
  "Secret": "someSecret"
};
